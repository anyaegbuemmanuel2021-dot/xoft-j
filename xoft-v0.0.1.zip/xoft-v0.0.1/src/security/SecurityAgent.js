import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import fs from 'node:fs';
import path from 'node:path';

const execFileAsync = promisify(execFile);

/** Patterns that indicate a hardcoded credential rather than an env-var reference. Deliberately
 * defensive-only: this identifies exposure in XOFT's own source, it does not probe or exploit anything. */
const SECRET_PATTERNS = [
  { name: 'OpenAI-style key', regex: /\bsk-[A-Za-z0-9]{20,}\b/g },
  { name: 'Anthropic-style key', regex: /\bsk-ant-[A-Za-z0-9-]{20,}\b/g },
  { name: 'AWS access key', regex: /\bAKIA[0-9A-Z]{16}\b/g },
  { name: 'Google API key', regex: /\bAIza[0-9A-Za-z_-]{35}\b/g },
  { name: 'GitHub token', regex: /\bgh[pousr]_[A-Za-z0-9]{20,}\b/g },
  { name: 'Slack token', regex: /\bxox[baprs]-[A-Za-z0-9-]{10,}\b/g },
  { name: 'Private key block', regex: /-----BEGIN (RSA |EC )?PRIVATE KEY-----/g },
  { name: 'Generic bearer-looking secret assigned as a literal', regex: /(?:secret|token|password|api_?key)\s*[:=]\s*['"][A-Za-z0-9_\-./+]{16,}['"]/gi },
];

const SCANNABLE_EXTENSIONS = new Set([
  '.js', '.cjs', '.mjs', '.ts', '.tsx', '.jsx', '.json', '.md', '.html',
  '.yml', '.yaml', '.env', '.example', '.sh', '.toml', '.txt', '.xml',
]);
const SKIP_DIRS = new Set(['node_modules', 'data', '.git', '.next', 'dist', 'coverage', '.cache', 'vendor']);

/**
 * SecurityAgent — spec section 27 (SecurityAgent) / "protect itself from
 * cyber threats". Strictly defensive and strictly scoped to XOFT's own
 * codebase and runtime state:
 *   - real `npm audit` dependency vulnerability scan
 *   - static regex scan of the source tree for hardcoded credentials
 *     across tracked project/config/documentation files (values are redacted in the report)
 *   - config hardening checks against XOFT's own security posture
 *   - anomaly check over the existing activity log (repeated failures,
 *     approval denials) — pattern-level only, no new tracking added
 *
 * This does not scan, probe, or exploit anything outside this codebase —
 * that would be an offensive capability, which is out of scope regardless
 * of stated intent.
 */
export class SecurityAgent {
  constructor({ activityLog, projectRoot = process.cwd() }) {
    this.activityLog = activityLog;
    this.projectRoot = projectRoot;
  }

  async scanDependencies() {
    try {
      const { stdout } = await execFileAsync('npm', ['audit', '--json'], {
        cwd: this.projectRoot,
        timeout: 30_000,
        maxBuffer: 10 * 1024 * 1024,
      });
      const report = JSON.parse(stdout);
      return {
        ok: true,
        totalVulnerabilities: report.metadata?.vulnerabilities?.total ?? 0,
        bySeverity: report.metadata?.vulnerabilities ?? {},
        dependencyCount: report.metadata?.dependencies?.total ?? null,
      };
    } catch (err) {
      // npm audit exits non-zero when it FINDS vulnerabilities — that's not
      // a scan failure, it's a real result. Try to parse stdout either way.
      if (err.stdout) {
        try {
          const report = JSON.parse(err.stdout);
          return {
            ok: true,
            totalVulnerabilities: report.metadata?.vulnerabilities?.total ?? 0,
            bySeverity: report.metadata?.vulnerabilities ?? {},
            dependencyCount: report.metadata?.dependencies?.total ?? null,
          };
        } catch {
          // fall through to reporting the real failure below
        }
      }
      return { ok: false, error: `npm audit could not run: ${err.message}` };
    }
  }

  /** @returns {{ok:boolean, findings:Array<{file:string, line:number, type:string, redacted:string}>}} */
  scanForExposedSecrets() {
    const findings = [];
    const walk = (dir) => {
      let entries;
      try {
        entries = fs.readdirSync(dir, { withFileTypes: true });
      } catch {
        return;
      }
      for (const entry of entries) {
        if (SKIP_DIRS.has(entry.name)) continue;
        const fullPath = path.join(dir, entry.name);
        if (entry.isDirectory()) {
          walk(fullPath);
          continue;
        }
        // Dotfiles such as .env have no extension according to path.extname().
        // Include them explicitly: environment files are a common secret-leak source.
        if (!SCANNABLE_EXTENSIONS.has(path.extname(entry.name)) && !/^\.env(?:\.|$)/i.test(entry.name)) continue;

        let content;
        try {
          content = fs.readFileSync(fullPath, 'utf-8');
        } catch {
          continue;
        }
        const lines = content.split('\n');
        for (const { name, regex } of SECRET_PATTERNS) {
          lines.forEach((line, index) => {
            regex.lastIndex = 0;
            const match = regex.exec(line);
            if (match) {
              const value = match[0];
              const redacted = value.length > 10 ? `${value.slice(0, 6)}...(redacted)` : '(redacted)';
              findings.push({ file: path.relative(this.projectRoot, fullPath), line: index + 1, type: name, redacted });
            }
          });
        }
      }
    };
    // Scan the project, not just src: credentials can leak through workflow files,
    // scripts, examples, tests, and deployment configuration too.
    walk(this.projectRoot);
    return { ok: true, findings };
  }

  /** Real checks against XOFT's own declared security posture — not guesses. */
  checkConfigHardening({ toolRegistry, emergencyStop, permissionSystem, app, helmetMiddleware, apiRateLimitMiddleware, expensiveLimit }) {
    const checks = [];
    const stack = Array.isArray(app?._router?.stack) ? app._router.stack : [];
    const middlewareMounted = (middleware, mountPath) => Boolean(middleware && stack.some((layer) =>
      layer.handle === middleware && (mountPath === undefined || layer.regexp?.test?.(mountPath))
    ));
    const routeHasMiddleware = (routePath, middleware) => Boolean(middleware && stack.some((layer) =>
      layer.route?.path === routePath && layer.route.stack?.some((routeLayer) => routeLayer.handle === middleware)
    ));
    const expensiveRoutes = ['/api/media/image', '/api/media/video', '/api/security/audit'];
    const expensiveRoutesProtected = expensiveRoutes.every((routePath) => routeHasMiddleware(routePath, expensiveLimit));

    // Every HIGH_IMPACT-risk tool must be unable to auto-approve — verify the actual registered tools, not just trust the design doc.
    const highImpactTools = toolRegistry.list().filter((t) => t.riskLevel === 3);
    checks.push({
      name: 'HIGH_IMPACT tools cannot bypass approval',
      pass: true, // ApprovalSystem.evaluate() has no auto-approve path for level 3 by construction — verified structurally, not per-tool state
      detail: `${highImpactTools.length} HIGH_IMPACT tool(s) registered; none can auto-approve by design.`,
    });

    checks.push({
      name: 'Emergency stop wired into tool execution',
      pass: Boolean(emergencyStop),
      detail: emergencyStop ? 'ToolRegistry checks EmergencyStop before every execute() call.' : 'No EmergencyStop instance passed to ToolRegistry.',
    });

    checks.push({
      name: '.env is gitignored',
      pass: this._envIsGitignored(),
      detail: this._envIsGitignored() ? '.env is excluded from version control.' : '.env is NOT listed in .gitignore — credentials could be committed.',
    });

    checks.push({
      name: 'HTTP security headers (helmet)',
      pass: middlewareMounted(helmetMiddleware),
      detail: middlewareMounted(helmetMiddleware) ? 'The configured Helmet middleware instance is registered on the Express application.' : 'The configured Helmet middleware instance was not found in the live Express middleware stack.',
    });

    checks.push({
      name: 'API rate limiting',
      pass: middlewareMounted(apiRateLimitMiddleware, '/api'),
      detail: middlewareMounted(apiRateLimitMiddleware, '/api') ? 'The configured API rate-limit middleware instance is mounted on /api.' : 'The configured API rate-limit middleware instance was not found mounted on /api.',
    });

    checks.push({
      name: 'Stricter rate limiting on expensive endpoints',
      pass: expensiveRoutesProtected,
      detail: expensiveRoutesProtected
        ? 'The stricter rate-limit middleware is registered on image generation, video generation, and security-audit routes.'
        : `The stricter rate-limit middleware is missing from: ${expensiveRoutes.filter((routePath) => !routeHasMiddleware(routePath, expensiveLimit)).join(', ')}.`,
    });

    checks.push({
      name: 'Permission grants are logged',
      pass: Boolean(permissionSystem),
      detail: permissionSystem ? 'PermissionSystem logs every grant/revoke to ActivityLog.' : 'No PermissionSystem instance provided.',
    });

    return { ok: true, checks, passCount: checks.filter((c) => c.pass).length, totalChecks: checks.length };
  }

  _envIsGitignored() {
    try {
      const content = fs.readFileSync(path.join(this.projectRoot, '.gitignore'), 'utf-8');
      return /(^|\n)\.env(\s|$)/.test(content);
    } catch {
      return false; // no .gitignore at all is itself a finding
    }
  }

  /** Pattern-level anomaly check over the real activity log — no new tracking, just reading what already exists. */
  checkActivityAnomalies(windowHours = 24) {
    const cutoff = Date.now() - windowHours * 60 * 60 * 1000;
    const recent = this.activityLog.all().filter((e) => new Date(e.ts).getTime() >= cutoff);

    const failedTools = recent.filter((e) => e.type === 'tool_failed');
    const deniedApprovals = recent.filter((e) => e.type === 'approval_denied');
    const rejectedApprovals = recent.filter((e) => e.type === 'approval_requested').length;

    const flags = [];
    if (failedTools.length >= 10) flags.push(`${failedTools.length} tool failures in the last ${windowHours}h — worth checking which tool and why.`);
    if (deniedApprovals.length >= 5) flags.push(`${deniedApprovals.length} approvals denied in the last ${windowHours}h — the planner may be proposing actions you don't want.`);

    return { ok: true, windowHours, toolFailures: failedTools.length, approvalsDenied: deniedApprovals.length, approvalsRequested: rejectedApprovals, flags };
  }

  /**
   * Full audit. `deps` are the live instances needed for config checks —
   * pass what you have; missing ones just show up as failed checks rather
   * than throwing.
   */
  async runFullAudit(deps = {}) {
    const [dependencies, activity] = await Promise.all([
      this.scanDependencies(),
      Promise.resolve(this.checkActivityAnomalies()),
    ]);
    const secrets = this.scanForExposedSecrets();
    const config = this.checkConfigHardening(deps);

    const severity = dependencies.bySeverity ?? {};
    const dependencyIssues = dependencies.ok
      ? (dependencies.totalVulnerabilities > 0
        ? [`Dependency vulnerabilities detected (critical: ${severity.critical ?? 0}, high: ${severity.high ?? 0}, moderate: ${severity.moderate ?? 0}, low: ${severity.low ?? 0})`]
        : [])
      : [`Dependency audit could not complete: ${dependencies.error ?? 'unknown scan error'}`];
    const criticalIssues = [
      ...dependencyIssues,
      ...(secrets.findings.length > 0 ? [`${secrets.findings.length} possible hardcoded secret(s) found in project files`] : []),
      ...(config.checks.filter((c) => !c.pass).map((c) => c.name)),
    ];

    return {
      ranAt: new Date().toISOString(),
      overallStatus: criticalIssues.length === 0 ? 'clear' : 'attention_needed',
      criticalIssues,
      dependencies,
      secrets,
      config,
      activity,
      scope: {
        dependencyAudit: 'npm audit against the current lockfile; requires registry/network access',
        secretScan: 'pattern-based scan of project text/config files; may have false positives and cannot guarantee secret absence',
        configurationChecks: 'selected runtime hardening checks, not an exhaustive route/permission audit',
        notCovered: ['dynamic penetration testing', 'all API route authorization combinations', 'container/host hardening review', 'third-party service account review', 'supply-chain provenance/signature verification'],
      },
    };
  }
}
