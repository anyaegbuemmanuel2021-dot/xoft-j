import dotenv from 'dotenv';
import { gatewayConfigFromEnv, gatewayConfigState } from '../providers/gatewayConfig.js';
dotenv.config();

function required(name, fallback = undefined) {
  return process.env[name] ?? fallback;
}

// Google shut down the Gemini 2.0 Flash family on 1 June 2026.
// Automatically migrate known retired IDs so a stale deployment variable
// cannot silently keep XOFT pinned to a model that no longer exists.
const RETIRED_GEMINI_MODELS = new Set([
  'gemini-2.0-flash',
  'gemini-2.0-flash-001',
  'gemini-2.0-flash-lite',
  'gemini-2.0-flash-lite-001',
]);

function configuredGeminiModel() {
  const model = String(required('GEMINI_MODEL', 'gemini-3.8-flash') ?? '').trim();
  if (!model || RETIRED_GEMINI_MODELS.has(model)) {
    if (model && RETIRED_GEMINI_MODELS.has(model)) {
      console.warn(`[XOFT] GEMINI_MODEL="${model}" has been retired. Switching to gemini-3.8-flash.`);
    }
    return 'gemini-3.8-flash';
  }
  return model;
}

export const config = {
  port: Number(required('PORT', 3000)),
  host: required('HOST', '0.0.0.0'),
  nodeEnv: required('NODE_ENV', 'development'),
  storage: {
    mode: required('STORAGE_MODE', 'sqlite'),
    sqlitePath: required('SQLITE_PATH', './data/xoft.sqlite'),
  },
  production: {
    requireAuth: String(required('REQUIRE_AUTH_IN_PRODUCTION', 'true')).toLowerCase() === 'true',
  },

  privacy: {
    // Opt-in: classify every model request and route SECRET/SENSITIVE data away from cloud providers.
    routing: String(required('PRIVACY_ROUTING', 'false')).toLowerCase() === 'true',
  },

  // Execution engines (Xoft Core + pluggable engines such as Hermes). Hermes-specific settings use HERMES_* (see docs/HERMES_ENGINE.md).
  engines: {
    maxConcurrentTasks: Number(required('ENGINES_MAX_CONCURRENT_TASKS', '3')),
    resumeOnStartup: String(required('ENGINES_RESUME_ON_STARTUP', 'true')).toLowerCase() === 'true',
    healthIntervalMs: Number(required('ENGINES_HEALTH_INTERVAL_MS', '30000')),
    gitSafetyNet: String(required('ENGINES_GIT_SAFETY_NET', 'true')).toLowerCase() === 'true',
    bridgeAllowRemote: String(required('HERMES_BRIDGE_ALLOW_REMOTE', 'false')).toLowerCase() === 'true',
  },

  watchdog: {
    enabled: String(required('WATCHDOG_ENABLED', 'true')).toLowerCase() === 'true',
    intervalMs: Number(required('WATCHDOG_INTERVAL_MS', '30000')),
  },

  memory: {
    dataDir: required('MEMORY_DATA_DIR', './data'),
  },

  devices: {
    // How long without a heartbeat/state update before a device is considered offline.
    onlineThresholdMs: required('DEVICE_ONLINE_THRESHOLD_MS', 90000),
    // How long a device command waits for the agent to report a result before timing out.
    commandTimeoutMs: required('DEVICE_COMMAND_TIMEOUT_MS', 30000),
    // Auto-trust a device that registers from 127.0.0.1/::1 — see isLoopback() in index.js.
    // Off by default; the combined PC launcher (xoft-pc/) turns this on for itself only.
    autoTrustLocal: String(required('AUTO_TRUST_LOCAL', 'false')).toLowerCase() === 'true',
  },

  auth: {
    // Comma-separated shared secrets. Empty = API is open (localhost/LAN dev only — see warning in index.js).
    apiKeys: String(required('AUTH_API_KEYS', ''))
      .split(',')
      .map((k) => k.trim())
      .filter(Boolean),
  },

  google: {
    clientId: required('GOOGLE_CLIENT_ID'),
    clientSecret: required('GOOGLE_CLIENT_SECRET'),
    refreshToken: required('GOOGLE_REFRESH_TOKEN'),
  },

  search: {
    // Set to a trusted SearXNG instance for keyless search (e.g. http://searxng:8080 in Docker Compose).
    searxngBaseUrl: String(required('SEARXNG_BASE_URL', '')).trim().replace(/\/+$/, ''),
    // Optional paid/free-tier fallback; never required when SearXNG is configured.
    braveApiKey: required('BRAVE_SEARCH_API_KEY'),
  },

  voice: {
    elevenLabsApiKey: required('ELEVENLABS_API_KEY'),
    elevenLabsVoiceId: required('ELEVENLABS_VOICE_ID', '21m00Tcm4TlvDq8ikWAM'),
    elevenLabsModel: String(required('ELEVENLABS_MODEL', 'eleven_flash_v2_5')).trim(),
    elevenLabsOutputFormat: String(required('ELEVENLABS_OUTPUT_FORMAT', 'mp3_22050_32')).trim(),
    // XOFT voice policy: Gemini first, OpenAI fallback (STT and TTS). Fixed order so a stale environment
    // variable can never reverse the required fallback. ElevenLabs is an optional last server voice for TTS.
    sttProviderOrder: ['gemini', 'openai'],
    // Latency hedge: if the first provider has not answered after this many ms, the next one starts in
    // parallel and the first usable answer wins (the slower request is cancelled).
    sttHedgeMs: Math.max(0, Number(process.env.STT_HEDGE_MS) || 800),
    ttsProviderOrder: String(process.env.TTS_PROVIDER_ORDER || 'gemini,openai,elevenlabs').split(',').map((x) => x.trim().toLowerCase()).filter(Boolean),
    ttsHedgeMs: Math.max(0, Number(process.env.TTS_HEDGE_MS) || 1200),
    geminiTtsModel: String(required('TTS_GEMINI_MODEL', 'gemini-2.5-flash-preview-tts')).trim(),
    geminiTtsVoice: String(required('TTS_GEMINI_VOICE', 'Kore')).trim(),
    openaiTtsModel: String(required('TTS_OPENAI_MODEL', 'gpt-4o-mini-tts')).trim(),
    openaiTtsVoice: String(required('TTS_OPENAI_VOICE', 'alloy')).trim(),
    sttLanguage: String(required('STT_LANGUAGE', '')).trim(),
    // gpt-4o-mini-transcribe is the default OpenAI transcription model; set STT_OPENAI_MODEL=whisper-1 for the legacy Whisper model.
    sttOpenAiModel: String(required('STT_OPENAI_MODEL', 'gpt-4o-mini-transcribe')).trim(),
    // Context is a spelling hint only. Language detection stays automatic unless STT_LANGUAGE is explicitly set.
    sttContextPrompt: String(required(
      'STT_CONTEXT_PROMPT',
      'Transcribe the audio verbatim, including natural pauses and code-switching. Accurately preserve Nigerian English and Igbo, including Nigerian Pidgin English and other Nigerian-language words mixed in the same sentence; do not translate them into English, paraphrase, normalize the speaker’s accent, or replace unfamiliar words with more common words. Possible spelling/context hints include XOFT, Softly Digitals, GitHub, Render, wetin, dey, don, abi, no wahala, how far, biko, kedu, daalu, nnoo, gini, ezigbo and “gee m aka”. These are examples only: include a term only when it is actually spoken, never inject example words from this prompt. Keep the speaker’s original language and wording, and add punctuation only where it helps readability. If the audio contains only silence or background noise, return no transcript; do not guess or infer words that are not clearly audible.'
    )).trim(),
    sttGeminiModel: String(required('STT_GEMINI_MODEL', '')).trim(), // empty = use the configured Gemini chat model
    sttTimeoutMs: Number(process.env.STT_TIMEOUT_MS) || 15000,
    ttsTimeoutMs: Number(process.env.TTS_TIMEOUT_MS) || 8000,
  },

  media: {
    // Image generation rides on the OpenAI key already configured above.
    imageModel: required('IMAGE_MODEL', 'gpt-image-2'),
    // Video generation rides on the Gemini key already configured below.
    // 'preview' in the model id reflects Google's own current model name as of this writing —
    // if it changes, calls fail with a real, specific error rather than silently doing nothing.
    videoModel: required('VIDEO_MODEL', 'veo-3.1-generate-preview'),
  },

  whatsapp: {
    accessToken: required('WHATSAPP_ACCESS_TOKEN'),
    phoneNumberId: required('WHATSAPP_PHONE_NUMBER_ID'),
    verifyToken: required('WHATSAPP_VERIFY_TOKEN'),
    appSecret: required('WHATSAPP_APP_SECRET'),
    apiVersion: required('WHATSAPP_API_VERSION', 'v23.0'),
  },

  twilio: {
    accountSid: required('TWILIO_ACCOUNT_SID'),
    authToken: required('TWILIO_AUTH_TOKEN'),
    fromNumber: required('TWILIO_FROM_NUMBER'),
    voiceWebhookUrl: required('TWILIO_VOICE_WEBHOOK_URL'),
    voiceResponseUrl: required('TWILIO_VOICE_RESPONSE_URL'),
    statusCallbackUrl: required('TWILIO_STATUS_CALLBACK_URL'),
    publicBaseUrl: required('TWILIO_PUBLIC_BASE_URL'),
  },

  task: {
    maxDurationMs: Math.max(1000, Number(required('TASK_MAX_DURATION_MS', 15 * 60 * 1000))),
  },

  connectors: {
    definitions: (() => {
      const raw = process.env.XOFT_CONNECTORS_JSON;
      if (!raw) return [];
      try { return JSON.parse(raw); } catch (err) { throw new Error(`Invalid XOFT_CONNECTORS_JSON: ${err.message}`); }
    })(),
  },

  providers: {
    openai: {
      apiKey: required('OPENAI_API_KEY'),
      chatModel: required('OPENAI_CHAT_MODEL', 'gpt-6-astra'),
      fastModel: required('OPENAI_FAST_MODEL', required('OPENAI_MODEL_EFFICIENT', 'gpt-6-luna')),
      // Explicit model tiers allow task-aware routing and manual tuning without code changes.
      models: {
        flagship: required('OPENAI_MODEL_FLAGSHIP', 'gpt-6-astra'),
        balanced: required('OPENAI_MODEL_BALANCED', 'gpt-6.1-sol'),
        efficient: required('OPENAI_MODEL_EFFICIENT', 'gpt-6-luna'),
        coding: required('OPENAI_MODEL_CODING', 'gpt-5.6-sol'),
        budget: required('OPENAI_MODEL_BUDGET', 'gpt-5.6-terra'),
      },
      embeddingModel: required('OPENAI_EMBEDDING_MODEL', 'text-embedding-3-small'),
    },
    gemini: {
      apiKey: required('GEMINI_API_KEY'),
      model: configuredGeminiModel(),
    },
    claude: {
      apiKey: required('ANTHROPIC_API_KEY'),
      model: required('ANTHROPIC_MODEL', 'claude-sonnet-5-5'),
    },
    xai: {
      apiKey: required('XAI_API_KEY'),
      model: required('XAI_MODEL', 'grok-4.7'),
    },
    experiential: {
      apiKey: required('EXPERIENTIAL_API_KEY'),
      baseUrl: required('EXPERIENTIAL_BASE_URL', 'https://api.experientiallabs.ai/v1'),
      model: required('EXPERIENTIAL_MODEL', 'gpt-5.6-luna'),
      freeOnly: String(required('EXPERIENTIAL_FREE_ONLY', 'true')).toLowerCase() === 'true',
    },
    // Optional OpenAI-compatible gateways. Both default to DISABLED and neither requires a key to exist for Xoft to boot: a missing or
    // malformed setting is a provider-level *state* (unconfigured / invalid_configuration), never a startup error. See docs/AI_GATEWAYS.md.
    freellmapi: gatewayConfigFromEnv('freellmapi'),
    litellm: gatewayConfigFromEnv('litellm'),
    ollama: {
      // Local model fallback — used when no cloud provider is configured, or when
      // every configured cloud provider fails (e.g. no internet). Off by default:
      // reaching for a network-absent local daemon on every call would otherwise
      // slow down the common case. Requires Ollama actually running locally
      // (https://ollama.com) with `model` already pulled.
      enabled: String(required('OLLAMA_ENABLED', 'false')).toLowerCase() === 'true',
      baseUrl: required('OLLAMA_BASE_URL', 'http://127.0.0.1:11434'),
      model: required('OLLAMA_MODEL', 'llama3.1'),
    },
  },

  // Optional global override of ProviderRouter's per-task-type preference
  // lists (see ProviderRouter._preferenceFor). When aiRouting.primaryProvider
  // is unset (the default), the router keeps its existing task-aware
  // ordering — e.g. Claude first for reasoning, OpenAI-fast first for
  // simple tasks — which is more useful than one global order. Setting it
  // pins a single provider first for EVERY task type instead; fallback
  // beyond it is only used when aiRouting.fallbackEnabled is true (default
  // true, matching the router's existing behavior), so a user who wants a
  // hard "never silently switch providers" guarantee can set
  // AI_FALLBACK_ENABLED=false and know only their chosen primary is ever tried.
  aiRouting: {
    fallbackEnabled: String(required('AI_FALLBACK_ENABLED', 'true')).toLowerCase() === 'true',
    primaryProvider: required('AI_PRIMARY_PROVIDER', null),
    fallbackProviders: String(required('AI_FALLBACK_PROVIDERS', ''))
      .split(',')
      .map((p) => p.trim())
      .filter(Boolean),
  },
};

/**
 * Returns which providers currently have credentials configured.
 * The router uses this to avoid ever pretending a provider works.
 */
export function availableProviders() {
  const avail = [];
  if (config.providers.openai.apiKey) avail.push('openai');
  if (config.providers.gemini.apiKey) avail.push('gemini');
  if (config.providers.claude.apiKey) avail.push('claude');
  if (config.providers.xai.apiKey) avail.push('grok');
  if (config.providers.experiential.apiKey) avail.push('experiential');
  if (gatewayConfigState('freellmapi', config.providers.freellmapi).configured) avail.push('freellmapi');
  if (gatewayConfigState('litellm', config.providers.litellm).configured) avail.push('litellm');
  if (config.providers.ollama.enabled) avail.push('ollama');
  return avail;
}

/** Which optional integrations are actually configured — used by /api/status and tool status. */
export function integrationStatus() {
  return {
    google: Boolean(config.google.clientId && config.google.clientSecret && config.google.refreshToken),
    braveSearch: Boolean(config.search.braveApiKey),
    elevenLabs: Boolean(config.voice.elevenLabsApiKey),
    whisper: Boolean(config.providers.openai.apiKey || config.providers.gemini.apiKey), // STT: Gemini first, OpenAI fallback
    imageGeneration: Boolean(config.providers.openai.apiKey), // rides on the OpenAI key
    videoGeneration: Boolean(config.providers.gemini.apiKey), // rides on the Gemini key
    connectors: config.connectors.definitions.filter((c) => c.enabled !== false).map((c) => c.id),
    whatsapp: Boolean(config.whatsapp.accessToken && config.whatsapp.phoneNumberId && config.whatsapp.verifyToken && config.whatsapp.appSecret),
    experiential: Boolean(config.providers.experiential.apiKey),
    freellmapi: gatewayConfigState('freellmapi', config.providers.freellmapi).configured,
    litellm: gatewayConfigState('litellm', config.providers.litellm).configured,
    twilio: Boolean(config.twilio.accountSid && config.twilio.authToken && config.twilio.fromNumber && config.twilio.voiceWebhookUrl && config.twilio.voiceResponseUrl),
  };
}
